<?php
require_once("dbconfig.php");

// $id = $_GET['id'];
if ($_POST){
    $id = $_POST['id'];
    // echo "<pre>";
    // print_r($_POST);
    $sql ="DELETE
           FROM doc_staff
           WHERE doc_id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    @$staff_id = $_POST['staff_id'];
    if (!empty($staff_id)) {
        for($i=0; $i<count($staff_id); $i++){
            $sql = "INSERT 
                    INTO doc_staff (doc_id, stf_id) 
                    VALUES (?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ss", $id, $staff_id[$i]);
            $stmt->execute();
    }
}
header("location: document.php");
}
else {
    $doc_id = $_GET['id'];
    $sql = "SELECT *
            FROM documents
            WHERE id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $doc_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_object();

    echo "<h1>รหัสคำสั่ง : $row->doc_num | ชื่อคำสั่ง: $row->doc_title</h1>";

    $sql = "SELECT *
            FROM staff LEFT JOIN (SELECT * FROM doc_staff WHERE doc_id = ?) ds ON staff.id = ds.stf_id
            ORDER BY staff.id";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $doc_id);
    $stmt->execute();
    $result = $stmt->get_result();
}
// for($i=0;$i<count($_POST['staff_id']);$i++){
//     // echo $_POST['staff_id'][$i];
//     $sql = "INSERT 
//             INTO doc_staff (doc_id, stf_id) 
//             VALUES (?, ?)";
//     $stmt = $mysqli->prepare($sql);
//     $stmt->bind_param("ii", $did, $_POST['staff_id'][$i]);
//     $stmt->execute();
// }

// $sql = "SELECT *
//         FROM staff LEFT JOIN (SELECT * FROM doc_staff WHERE doc_id = ?) ds ON staff.id = ds.stf_id
//         ORDER BY staff.id";
//         $stmt = $mysqli->prepare($sql);
//         $stmt->bind_param("i", $doc_id);
//         $stmt->execute();
//         $result = $stmt->get_result();
?>



<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<html>
<style>
.ccb {
    align: center;
}
</style>
</html>
<p class="ccb">
<form action="addstafftodoc.php" method="post">
    <input type="hidden" name="id" value="<?php echo $doc_id; ?>">
    <?php
    while($row = $result->fetch_object()){?>
    <div class="checkbox">
    <?php echo "<input type='checkbox' name='staff_id[]' value='$row->id'>$row->stf_name<br>";
}?>
</p>
    <input type="submit">
</form>
